import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import TransactionsStack from './TransactionsStack';
import SummaryScreen from '../screens/SummaryScreen';
import AddTransactionScreen from '../screens/Addtranscations';

const Tab = createBottomTabNavigator();

const AppNavigator = () => (
  <Tab.Navigator>
    <Tab.Screen name="Transactions" component={TransactionsStack} />
    <Tab.Screen name="Summary" component={SummaryScreen} />
    <Tab.Screen name="Add Transaction" component={AddTransactionScreen} />
  </Tab.Navigator>
);

export default AppNavigator;
