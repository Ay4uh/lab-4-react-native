export const transactions = [
    { id: '1', name: 'Starbucks', amount: '12.00', date: '2024-03-20' },
    { id: '2', name: 'Apple Store', amount: '101.00', date: '2024-03-18' },
    // ...more transactions
  ];
  